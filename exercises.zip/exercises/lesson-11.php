<?php require "../components/head.php"?>
		<title>More Crossovers, Dot Cuts, F & E Doublings Beginner Exercises for Bagpipes</title>
		<?php $content = "Lesson 11 - More Crossovers, Dot Cuts, F &amp; E Doublings Beginner Exercises for Bagpipes";?>
		<meta name="description" content="<?php echo $content;?>">
		<link rel=“canonical” href=“https://www.nycbagpipes.com/exercises/lesson-11.php">
		<meta property="og:description" content="<?php echo $content;?>">
	</head>
  <body>
		<?php require "../components/googleTagBody.php";?>
			<img class="music-notation" src="./jpg/lesson-11-1.jpg" alt="Lesson 11 - More Crossovers, Dot Cuts, F and E Doublings Beginner Exercises for Bagpipes">
			<?php require "../components/footer.php";?>
		<script src="../script.js"></script>
	</body>
</html>
