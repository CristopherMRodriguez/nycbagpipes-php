<?php require "../components/head.php"?>
		<title>C Doublings, B Doublings, More Crossovers Beginner Exercises for Bagpipes</title>
		<?php $content = "Lesson 9 - C Doublings, B Doublings, More Crossover Beginner Exercises for Bagpipes</a>";?>
		<meta name="description" content="<?php echo $content;?>">
		<link rel=“canonical” href=“https://www.nycbagpipes.com/exercises/lesson-9.php">
		<meta property="og:description" content="<?php echo $content;?>">
	</head>
  <body>
		<?php require "../components/googleTagBody.php";?>
			<img class="music-notation" src="./jpg/lesson-9-1.jpg" alt="Bagpipe exercises for C Doublings, B Doublings, More Crossover Beginner Exercises for Bagpipes">
			<?php require "../components/footer.php";?>
		<script src="../script.js"></script>
	</body>
</html>
