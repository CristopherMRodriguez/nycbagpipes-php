<?php require "../components/head.php"?>
		<title>Bagpipe 6/8 Rhythms, Crossover exercises, B taps (to A) Beginner Exercises for Bagpipes</title>
		<?php $content = "Lesson 4 - 6/8 Rhythms, Crossovers, B taps (to A)";?>
		<meta name="description" content="<?php echo $content;?>">
		<link rel=“canonical” href=“https://www.nycbagpipes.com/exercises/lesson-4.php">
		<meta property="og:description" content="<?php echo $content;?>">
	</head>
  <body>
		<?php require "../components/googleTagBody.php";?>
			<img class="music-notation" src="./jpg/lesson-4.jpg" alt="6/8 Bagpipe Rhythms, Crossover Exercises, B taps (to A) Exercise">
			<?php require "../components/footer.php";?>
		<script src="../script.js"></script>
	</body>
</html>
